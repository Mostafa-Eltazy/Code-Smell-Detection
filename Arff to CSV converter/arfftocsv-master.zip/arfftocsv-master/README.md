# ARFF to CSV converter
A python script to convert ARFF files to CSV

## Usage
1. Put all your .arff files in a directory
2. Place this script in the same directory as the files
3. Run the script
4. All the CSV files will be created in the same directory

```
python arffToCsv.py
```

## Having an issue?
Raise an issue and I'll try to resolve it as soon as possible
